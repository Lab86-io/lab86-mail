import { positionToZone } from "../../../helpers";
import { PositionMap } from "../../../helpers/cells/position_map";
import { BoundedRange, CellPosition } from "../../../types";
import { DependenciesRTree } from "./dependencies_r_tree";
import { RTreeBoundingBox, RTreeItem } from "./r_tree";
import { RangeSet } from "./range_set";

/**
 * Implementation of a dependency Graph.
 * The graph is used to evaluate the cells in the correct
 * order, and should be updated each time a cell's content is modified
 *
 * It uses an R-Tree data structure to efficiently find dependent cells.
 */
export class FormulaDependencyGraph {
  private readonly dependencies: PositionMap<RTreeItem<BoundedRange>[]> = new PositionMap();
  private readonly rTree: DependenciesRTree;

  constructor(data: RTreeItem<BoundedRange>[] = []) {
    this.rTree = new DependenciesRTree(data);
  }

  removeAllDependencies(formulaPosition: CellPosition) {
    const ranges = this.dependencies.get(formulaPosition);
    if (!ranges) {
      return;
    }
    for (const range of ranges) {
      this.rTree.remove(range);
    }
    this.dependencies.delete(formulaPosition);
  }

  addDependencies(formulaPosition: CellPosition, dependencies: RTreeBoundingBox[]): void {
    const rTreeItems = dependencies.map(({ sheetId, zone }) => ({
      data: {
        sheetId: formulaPosition.sheetId,
        zone: positionToZone(formulaPosition),
      },
      boundingBox: {
        zone,
        sheetId,
      },
    }));
    for (const item of rTreeItems) {
      this.rTree.insert(item);
    }
    const existingDependencies = this.dependencies.get(formulaPosition);
    if (existingDependencies) {
      existingDependencies.push(...rTreeItems);
    } else {
      this.dependencies.set(formulaPosition, rTreeItems);
    }
  }

  /**
   * Return all the cells that depend on the provided ranges.
   */
  getCellsDependingOn(ranges: Iterable<BoundedRange>, visited = new RangeSet()): RangeSet {
    visited = visited.copy();

    // At the end we want to remove from the visited set all the initial range positions, except the ones we're actually depending on
    // Some of the cells of the initial ranges might be depending on other cells of the initial ranges, and we want to keep those in the visited set
    let initialRangesToRemove = visited.copy();

    const queue: BoundedRange[] = Array.from(ranges).reverse();
    while (queue.length > 0) {
      const range = queue.pop()!;
      visited.add(range);
      const impactedRanges = this.rTree.search(range);
      queue.push(...impactedRanges.difference(visited));
      initialRangesToRemove = initialRangesToRemove.difference(impactedRanges);
    }

    // remove initial ranges
    for (const range of initialRangesToRemove) {
      visited.delete(range);
    }

    return visited;
  }
}
