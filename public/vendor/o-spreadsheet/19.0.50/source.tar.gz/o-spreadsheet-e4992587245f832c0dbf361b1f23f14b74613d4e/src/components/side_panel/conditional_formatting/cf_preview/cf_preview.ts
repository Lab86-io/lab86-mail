import { Component, useRef } from "@odoo/owl";
import { CF_ICON_EDGE_LENGTH, GRAY_200, GRAY_300, HIGHLIGHT_COLOR } from "../../../../constants";
import { colorNumberToHex } from "../../../../helpers";
import { criterionEvaluatorRegistry } from "../../../../registries/criterion_registry";
import { ConditionalFormat, Highlight, SpreadsheetChildEnv } from "../../../../types";
import { cellStyleToCss, css, cssPropertiesToCss } from "../../../helpers";
import { useHighlightsOnHover } from "../../../helpers/highlight_hook";
import { ICONS } from "../../../icons/icons";
import { CfTerms } from "../../../translations_terms";

css/* scss */ `
  .o-spreadsheet .o-cf-preview {
    &.o-cf-cursor-ptr {
      cursor: pointer;
    }

    border-bottom: 1px solid ${GRAY_300};
    height: 80px;
    padding: 10px;
    box-sizing: border-box;
    position: relative;
    cursor: pointer;
    &:hover,
    &.o-cf-dragging {
      background-color: ${GRAY_200};
    }

    &:not(:hover) .o-cf-delete-button {
      display: none;
    }
    .o-cf-preview-icon {
      border: 1px solid ${GRAY_300};
      background-color: #fff;
      height: 50px;
      width: 50px;
      .o-icon {
        width: ${CF_ICON_EDGE_LENGTH}px;
        height: ${CF_ICON_EDGE_LENGTH}px;
      }
    }
    .o-cf-preview-description {
      .o-cf-preview-description-rule {
        margin-bottom: 4px;
        max-height: 2.8em;
        line-height: 1.4em;
      }
      .o-cf-preview-range {
        font-size: 12px;
      }
    }
    &:not(:hover):not(.o-cf-dragging) .o-cf-drag-handle {
      display: none !important;
    }
    .o-cf-drag-handle {
      left: 2px;
      cursor: move;
      .o-icon {
        width: 6px;
        height: 30px;
      }
    }

    .o-icon.arrow-down {
      color: #e06666;
    }
    .o-icon.arrow-up {
      color: #6aa84f;
    }
  }
`;
interface Props {
  conditionalFormat: ConditionalFormat;
  onPreviewClick: () => void;
  onMouseDown: (ev: MouseEvent) => void;
  class: string;
}

export class ConditionalFormatPreview extends Component<Props, SpreadsheetChildEnv> {
  static template = "o-spreadsheet-ConditionalFormatPreview";

  icons = ICONS;

  private ref = useRef("cfPreview");

  setup() {
    useHighlightsOnHover(this.ref, this);
  }

  getPreviewImageStyle(): string {
    const rule = this.props.conditionalFormat.rule;
    if (rule.type === "CellIsRule") {
      return cssPropertiesToCss(cellStyleToCss(rule.style));
    } else if (rule.type === "ColorScaleRule") {
      const minColor = colorNumberToHex(rule.minimum.color);
      const midColor = rule.midpoint ? colorNumberToHex(rule.midpoint.color) : null;
      const maxColor = colorNumberToHex(rule.maximum.color);
      const baseString = "background-image: linear-gradient(to right, ";
      return midColor
        ? baseString + minColor + ", " + midColor + ", " + maxColor + ")"
        : baseString + minColor + ", " + maxColor + ")";
    } else if (rule.type === "DataBarRule") {
      const color = colorNumberToHex(rule.color);
      return `background-image: linear-gradient(to right, ${color} 50%, white 50%)`;
    }
    return "";
  }

  getDescription(): string {
    const cf = this.props.conditionalFormat;
    switch (cf.rule.type) {
      case "CellIsRule":
        return criterionEvaluatorRegistry
          .get(cf.rule.operator)
          .getPreview({ ...cf.rule, type: cf.rule.operator }, this.env.model.getters);
      case "ColorScaleRule":
        return CfTerms.ColorScale;
      case "IconSetRule":
        return CfTerms.IconSet;
      case "DataBarRule":
        return CfTerms.DataBar;
    }
  }

  deleteConditionalFormat() {
    this.env.model.dispatch("REMOVE_CONDITIONAL_FORMAT", {
      id: this.props.conditionalFormat.id,
      sheetId: this.env.model.getters.getActiveSheetId(),
    });
  }

  onMouseDown(event: MouseEvent) {
    this.props.onMouseDown(event);
  }

  get highlights(): Highlight[] {
    const sheetId = this.env.model.getters.getActiveSheetId();
    return this.props.conditionalFormat.ranges.map((range) => ({
      range: this.env.model.getters.getRangeFromSheetXC(sheetId, range),
      color: HIGHLIGHT_COLOR,
      fillAlpha: 0.06,
    }));
  }
}

ConditionalFormatPreview.props = {
  conditionalFormat: Object,
  onPreviewClick: Function,
  onMouseDown: Function,
  class: String,
};
