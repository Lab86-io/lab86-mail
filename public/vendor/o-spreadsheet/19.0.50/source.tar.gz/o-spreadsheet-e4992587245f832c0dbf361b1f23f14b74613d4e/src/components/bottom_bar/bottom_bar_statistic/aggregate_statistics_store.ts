import { sum } from "../../../functions/helper_math";
import { average, countAny, countNumbers, max, min } from "../../../functions/helper_statistical";
import { lazy, memoize, recomputeZones } from "../../../helpers";
import { Get } from "../../../store_engine";
import { SpreadsheetStore } from "../../../stores";
import { _t } from "../../../translation";
import {
  CellValueType,
  Command,
  EvaluatedCell,
  Lazy,
  Locale,
  invalidateEvaluationCommands,
} from "../../../types";

export interface StatisticFnResults {
  [name: string]: Lazy<number> | undefined;
}

interface SelectionStatisticFunction {
  name: string;
  compute: (data: EvaluatedCell[], locale: Locale) => number;
  types: CellValueType[];
}

const selectionStatisticFunctions: SelectionStatisticFunction[] = [
  {
    name: _t("Sum"),
    types: [CellValueType.number],
    compute: (values, locale) => sum([[values]], locale),
  },
  {
    name: _t("Avg"),
    types: [CellValueType.number],
    compute: (values, locale) => average([[values]], locale),
  },
  {
    name: _t("Min"),
    types: [CellValueType.number],
    compute: (values, locale) => min([[values]], locale).value,
  },
  {
    name: _t("Max"),
    types: [CellValueType.number],
    compute: (values, locale) => max([[values]], locale).value,
  },
  {
    name: _t("Count"),
    types: [CellValueType.number, CellValueType.text, CellValueType.boolean, CellValueType.error],
    compute: (values) => countAny([[values]]),
  },
  {
    name: _t("Count Numbers"),
    types: [CellValueType.number, CellValueType.text, CellValueType.boolean, CellValueType.error],
    compute: (values, locale) => countNumbers([[values]], locale),
  },
];

export class AggregateStatisticsStore extends SpreadsheetStore {
  statisticFnResults: StatisticFnResults = this._computeStatisticFnResults();
  private isDirty = false;

  constructor(get: Get) {
    super(get);
    this.model.selection.observe(this, {
      handleEvent: this.handleEvent.bind(this),
    });
  }

  handle(cmd: Command) {
    if (
      invalidateEvaluationCommands.has(cmd.type) ||
      (cmd.type === "UPDATE_CELL" && ("content" in cmd || "format" in cmd))
    ) {
      this.isDirty = true;
    }
    switch (cmd.type) {
      case "HIDE_COLUMNS_ROWS":
      case "UNHIDE_COLUMNS_ROWS":
      case "GROUP_HEADERS":
      case "UNGROUP_HEADERS":
      case "ACTIVATE_SHEET":
      case "ACTIVATE_NEXT_SHEET":
      case "ACTIVATE_PREVIOUS_SHEET":
      case "EVALUATE_CELLS":
      case "UNDO":
      case "REDO":
        this.isDirty = true;
    }
  }

  finalize() {
    if (this.isDirty) {
      this.isDirty = false;
      this.statisticFnResults = this._computeStatisticFnResults();
    }
  }

  handleEvent() {
    if (this.getters.isGridSelectionActive()) {
      this.statisticFnResults = this._computeStatisticFnResults();
    }
  }

  private _computeStatisticFnResults(): StatisticFnResults {
    const getters = this.getters;
    const sheetId = getters.getActiveSheetId();
    const cells: EvaluatedCell[] = [];

    const recomputedZones = recomputeZones(getters.getSelectedZones(), []);
    const heightMax = this.getters.getSheetSize(sheetId).numberOfRows - 1;
    const widthMax = this.getters.getSheetSize(sheetId).numberOfCols - 1;

    for (const zone of recomputedZones) {
      for (let col = zone.left; col <= (zone.right ?? widthMax); col++) {
        for (let row = zone.top; row <= (zone.bottom ?? heightMax); row++) {
          if (getters.isRowHidden(sheetId, row) || getters.isColHidden(sheetId, col)) {
            continue; // Skip hidden cells
          }

          const evaluatedCell = getters.getEvaluatedCell({ sheetId, col, row });
          if (evaluatedCell.type !== CellValueType.empty) {
            cells.push(evaluatedCell);
          }
        }
      }
    }
    const locale = getters.getLocale();
    const statisticFnResults: StatisticFnResults = {};

    const getCells = memoize((typeStr: string) => {
      const types = typeStr.split(",");
      return cells.filter((c) => types.includes(c.type));
    });
    for (const fn of selectionStatisticFunctions) {
      // We don't want to display statistical information when there is no interest:
      // We set the statistical result to undefined if the data handled by the selection
      // does not match the data handled by the function.
      // Ex: if there are only texts in the selection, we prefer that the SUM result
      // be displayed as undefined rather than 0.
      let fnResult: Lazy<number> | undefined = undefined;
      const evaluatedCells = getCells(fn.types.sort().join(","));
      if (evaluatedCells.length) {
        fnResult = lazy(() => fn.compute(evaluatedCells, locale));
      }
      statisticFnResults[fn.name] = fnResult;
    }
    return statisticFnResults;
  }
}
