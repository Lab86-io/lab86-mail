import { Component, useExternalListener, useRef, useState } from "@odoo/owl";
import { GRAY_300 } from "../../../../constants";
import { Rect, SpreadsheetChildEnv } from "../../../../types";
import { ColorPicker } from "../../../color_picker/color_picker";
import { css, cssPropertiesToCss } from "../../../helpers";
import { getBoundingRectAsPOJO } from "../../../helpers/dom_helpers";
import { TRANSPARENT_BACKGROUND_SVG } from "../../../icons/raw_svgs";
import { Section } from "../section/section";

interface State {
  pickerOpened: boolean;
}

interface Props {
  currentColor?: string;
  onColorPicked: (color: string) => void;
  title?: string;
  disableNoColor?: boolean;
}

css/* scss */ `
  .o-round-color-picker-button {
    width: 20px;
    height: 20px;
    cursor: pointer;
    border: 1px solid ${GRAY_300};
    background-position: 1px 1px;
    background-image: url("data:image/svg+xml,${encodeURIComponent(TRANSPARENT_BACKGROUND_SVG)}");
  }
`;

export class RoundColorPicker extends Component<Props, SpreadsheetChildEnv> {
  static template = "o-spreadsheet.RoundColorPicker";
  static components = { Section, ColorPicker };
  static props = {
    currentColor: { type: String, optional: true },
    title: { type: String, optional: true },
    onColorPicked: Function,
    disableNoColor: { type: Boolean, optional: true },
  };

  colorPickerButtonRef = useRef("colorPickerButton");

  private state!: State;

  setup() {
    this.state = useState({ pickerOpened: false });
    useExternalListener(window as any, "click", this.closePicker);
  }

  closePicker() {
    this.state.pickerOpened = false;
  }

  togglePicker() {
    this.state.pickerOpened = !this.state.pickerOpened;
  }

  onColorPicked(color: string) {
    this.props.onColorPicked(color);
    this.state.pickerOpened = false;
  }

  get colorPickerAnchorRect(): Rect {
    const button = this.colorPickerButtonRef.el!;
    return getBoundingRectAsPOJO(button);
  }

  get buttonStyle() {
    return cssPropertiesToCss({
      background: this.props.currentColor,
    });
  }
}
