import { Component, useRef, useState } from "@odoo/owl";
import { SpreadsheetPivotRuntimeDefinition } from "../../../../../helpers/pivot/spreadsheet_pivot/runtime_definition_spreadsheet_pivot";
import { SpreadsheetPivot } from "../../../../../helpers/pivot/spreadsheet_pivot/spreadsheet_pivot";
import { Store, useLocalStore } from "../../../../../store_engine";
import { Ref, SpreadsheetChildEnv, UID } from "../../../../../types";
import { SpreadsheetPivotCoreDefinition } from "../../../../../types/pivot";
import { SelectionInput } from "../../../../selection_input/selection_input";
import { Checkbox } from "../../../components/checkbox/checkbox";
import { Section } from "../../../components/section/section";
import { PivotDeferUpdate } from "../../pivot_defer_update/pivot_defer_update";
import { PivotLayoutConfigurator } from "../../pivot_layout_configurator/pivot_layout_configurator";
import { PivotTitleSection } from "../../pivot_title_section/pivot_title_section";
import { PivotSidePanelStore } from "../pivot_side_panel_store";

interface Props {
  pivotId: UID;
  onCloseSidePanel: () => void;
}

export class PivotSpreadsheetSidePanel extends Component<Props, SpreadsheetChildEnv> {
  static template = "o-spreadsheet-PivotSpreadsheetSidePanel";
  static props = {
    pivotId: String,
    onCloseSidePanel: Function,
  };
  static components = {
    PivotLayoutConfigurator,
    Section,
    SelectionInput,
    Checkbox,
    PivotDeferUpdate,
    PivotTitleSection,
  };
  store!: Store<PivotSidePanelStore>;

  state!: { range?: string; rangeHasChanged: boolean };

  pivotSidePanelRef: Ref<HTMLElement> = useRef("pivotSidePanel");

  setup() {
    this.store = useLocalStore(PivotSidePanelStore, this.props.pivotId);
    this.state = useState({
      range: undefined,
      rangeHasChanged: false,
    });
  }

  get shouldDisplayInvalidRangeError() {
    if (this.store.isDirty && this.state.rangeHasChanged) {
      return false;
    }
    return this.pivot.isInvalidRange;
  }

  get ranges() {
    if (this.state.range) {
      return [this.state.range];
    }
    if (this.definition.range) {
      return [this.env.model.getters.getRangeString(this.definition.range, "forceSheetReference")];
    }
    return [];
  }

  get pivot() {
    return this.store.pivot as SpreadsheetPivot;
  }

  get definition(): SpreadsheetPivotRuntimeDefinition {
    return this.store.definition as SpreadsheetPivotRuntimeDefinition;
  }

  getScrollableContainerEl() {
    return this.pivotSidePanelRef.el;
  }

  onSelectionChanged(ranges: string[]) {
    this.state.rangeHasChanged = true;
    if (ranges.length === 0) {
      this.state.range = undefined;
      return;
    }
    const sheetId = this.env.model.getters.getActiveSheetId();
    const range = this.env.model.getters.getRangeFromSheetXC(sheetId, ranges[0]);
    this.state.range = this.env.model.getters.getRangeString(range, "forceSheetReference", {
      useBoundedReference: true,
    });
  }

  onSelectionConfirmed() {
    if (this.state.range) {
      const range = this.env.model.getters.getRangeFromSheetXC(
        this.env.model.getters.getActiveSheetId(),
        this.state.range
      );
      if (range.invalidSheetName || range.invalidXc) {
        return;
      }

      const dataSet = { sheetId: range.sheetId, zone: range.zone };
      this.store.update({ dataSet });
      // Immediately apply the update to recompute the pivot fields
      this.store.applyUpdate();
    }
  }

  flipAxis() {
    const { rows, columns } = this.definition;
    this.onDimensionsUpdated({
      rows: columns,
      columns: rows,
    });
  }

  onDimensionsUpdated(definition: Partial<SpreadsheetPivotCoreDefinition>) {
    this.store.update(definition);
  }
}
