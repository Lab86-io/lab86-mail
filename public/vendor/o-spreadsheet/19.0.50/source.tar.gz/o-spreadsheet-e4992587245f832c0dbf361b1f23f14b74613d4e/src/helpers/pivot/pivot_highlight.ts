import { HIGHLIGHT_COLOR } from "../../constants";
import { CellPosition, Getters, Highlight, UID } from "../../types";
import { mergeContiguousZones, positionToZone } from "../zones";

export function getPivotHighlights(getters: Getters, pivotId: UID): Highlight[] {
  const sheetId = getters.getActiveSheetId();
  const pivotCellPositions = getVisiblePivotCellPositions(getters, pivotId);
  const mergedZones = mergeContiguousZones(pivotCellPositions.map(positionToZone));
  return mergedZones.map((zone) => ({
    range: getters.getRangeFromZone(sheetId, zone),
    noFill: true,
    color: HIGHLIGHT_COLOR,
  }));
}

function getVisiblePivotCellPositions(getters: Getters, pivotId: UID) {
  const positions: CellPosition[] = [];
  const sheetId = getters.getActiveSheetId();
  for (const col of getters.getSheetViewVisibleCols()) {
    for (const row of getters.getSheetViewVisibleRows()) {
      const position = { sheetId, col, row };
      const cellPivotIds = getters.getPivotIdsFromPosition(position);
      if (cellPivotIds.includes(pivotId)) {
        positions.push(position);
      }
    }
  }
  return positions;
}
